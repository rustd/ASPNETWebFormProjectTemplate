-----------------------------------------------------------------------------------------------------
Description
-----------------------------------------------------------------------------------------------------
This project template contains the enhanced project template for ASP.NET WebForms that shipped with Visual Studio 2012.
This project template has the following features
--- Social Login: Login using OAuth/OpenID support to login using Facebook, Twitter, Google, Microsoft account etc
--- Demonstrate the best of standards for HTML5, CSS and Javascript
--- All assets are managed via Nuget packages which make it easier to manage the assets
--- Cloud Ready: The templates can be published to Windows Azure as it is.


-----------------------------------------------------------------------------------------------------
How to Build this template
-----------------------------------------------------------------------------------------------------
THe assets of the templates are containied as Nuget packages. You need to download the nuget packages before you build the project.
Once you create the project, follow the steps listed here for "Enabling package restore" which will download all the packages and then the 
project can be built successfully
http://docs.nuget.org/docs/workflows/using-nuget-without-committing-packages


-----------------------------------------------------------------------------------------------------
Pre-Requisites
-----------------------------------------------------------------------------------------------------
--- You need Visual Studio 2010 SP1
--- IISExpress 7.5 or above
--- Nuget 2.0 or above